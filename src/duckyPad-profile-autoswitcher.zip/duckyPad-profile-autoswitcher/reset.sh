git reset --hard HEAD; git clean -f -d
